# Express REST API - Course & Category Management System

This is a modular REST API project built using Express.js and MongoDB following the MVC architecture.

## Modules
1. **Authentication System (`/api/auth`)**: User Register & Login with JWT Authentication.
2. **Category Module (`/api/categories`)**: CRUD operations for course categories.
3. **Course Module (`/api/courses`)**: CRUD operations for courses linked with categories.

## Submission Instructions
- Extract this ZIP file.
- Run `npm install` inside the project folder.
- Start your MongoDB service.
- Run `npm run dev` to start the server at `http://localhost:5000`.
