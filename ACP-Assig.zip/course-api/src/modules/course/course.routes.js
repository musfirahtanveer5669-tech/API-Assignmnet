const express = require('express');
const { createCourse, getCourses } = require('./course.controller');
const { protect } = require('../../middleware/auth.middleware');

const router = express.Router();

router.route('/')
  .get(getCourses)
  .post(protect, createCourse);

module.exports = router;
