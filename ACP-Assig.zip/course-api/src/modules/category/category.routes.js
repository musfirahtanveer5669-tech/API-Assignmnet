const express = require('express');
const { createCategory, getCategories } = require('./category.controller');
const { protect } = require('../../middleware/auth.middleware');

const router = express.Router();

router.route('/')
  .get(getCategories)
  .post(protect, createCategory);

module.exports = router;
